#include "simpletools.h"
#include "abcalibrate360.h"    

int main()
{
  high(26);
  high(27);
  cal_activityBot();
  low(26);
  low(27);
}



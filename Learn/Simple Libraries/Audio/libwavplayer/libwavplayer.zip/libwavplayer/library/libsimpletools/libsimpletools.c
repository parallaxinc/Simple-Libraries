#include "simpletools.h"
main()
{
}
/*
  Hello Message.c
  
  Click Help and select Tutorials to see lots of code and application examples. 
  
  http://learn.parallax.com/propeller-c-start-simple/simple-hello-message
*/

#include "simpletools.h"                      // Include simpletools header

int main()                                    // main function
{
  pause(1000);                                // Wait 1 s for host
  printf("Hello!!!");                         // Display a message
}

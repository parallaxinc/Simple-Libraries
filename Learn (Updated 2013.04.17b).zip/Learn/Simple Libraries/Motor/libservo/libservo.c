#include "servo.h"
#include "simpletools.h"

int main()
{
  servo_angle(4, 90);
  while(1);
}

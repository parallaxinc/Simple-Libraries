#include "simpletools.h"
#include "ping.h"

int main()
{
}

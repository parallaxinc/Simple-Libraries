#include "simpletools.h"   
#include "mx2125.h" 

int main()                                   
{
/*
  while(1)                                    
  {
    int x = mx_x(5);
    int y = mx_x(6);
    int angle = mx_rotation(5, 6);
    int xtilt = mx_tilt_x(5);
    
    printf("%cx = %d, y = %d, angle = %d, x tilt = %d%c\n", 
            HOME, x, y, angle, xtilt, CLREOL);
    pause(200);    
  }
*/    
}

